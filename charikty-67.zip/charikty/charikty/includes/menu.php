<div class="menu">
	<ul>
		<li><a href="moncompte.php">ACCUEIL</a></li>
<li><a href="mesdossiers.php" class="active">MES DOCUMENTS</a></li>
    <li><a href="mesfactures.php">MES FACTURES</a></li>
    <li><a href="monprofile.php">MON PROFIL</a>
    <li><a href="">DÉCONNEXION</a></li>
	</ul>

</div>

